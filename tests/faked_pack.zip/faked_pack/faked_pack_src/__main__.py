import sys

# if __name__ == '__main__':
#     sys.exit('This is only for testing and fake')

from faked_pack_src import call_and_return

call_and_return(print)
